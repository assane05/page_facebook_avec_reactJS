import React from 'react';
import logo from './logo.svg';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Facebook from './components/Facebook';

function App() {
  return (
    <div>
      <Facebook />
    </div>
  );
}

export default App;
